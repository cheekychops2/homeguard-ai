# HomeGuard AI

Production-ready Next.js App Router MVP scaffold for Vercel.

## Run locally

npm install
npm run dev

## Deploy to Vercel

1. Create a GitHub repository named `homeguard-ai`.
2. Upload the contents of this folder to the repository root.
3. In Vercel, import the GitHub repository.
4. Framework: Next.js; Root Directory: `./`.
5. Deploy the `main` branch.

This first deployment intentionally works without external API keys. Supabase, Stripe and AI integrations are represented by environment-variable placeholders and should be connected after the production shell is live.
