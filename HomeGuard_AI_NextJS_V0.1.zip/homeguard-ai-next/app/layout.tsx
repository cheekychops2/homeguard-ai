import './globals.css';
import Link from 'next/link';
export const metadata={title:'HomeGuard AI',description:'AI-powered home maintenance and property protection'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body><aside><div className="brand">🏠 <span>HomeGuard <b>AI</b></span></div><nav><Link href="/">Dashboard</Link><Link href="/property">My Property</Link><Link href="/maintenance">Maintenance</Link><Link href="/inspect">AI Inspect</Link><Link href="/trades">Find a Trade</Link><Link href="/settings">Settings</Link></nav><div className="sideNote"><b>Home Health</b><strong>82/100</strong><span>Good condition</span></div></aside><main>{children}</main></body></html>}
