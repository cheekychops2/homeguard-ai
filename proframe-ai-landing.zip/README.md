# ProFrame AI

**Studio-quality professional headshots and portraits from your selfies — in minutes.**

A one-person AI SaaS that generates professional headshots, LinkedIn photos, and industry-specific portraits using AI.

## Vision
Build a profitable, solo-operated AI product that can scale to multi-million ARR by solving a high-value, recurring need for professionals worldwide.

## Current Status
- [x] Product concept validated against proven competitors (Photo AI, HeadshotPro, etc.)
- [ ] Landing page + waitlist
- [ ] Full MVP scaffold
- [ ] AI generation pipeline
- [ ] Payments & user dashboard
- [ ] Launch

## Quick Start (Coming Soon)
Detailed setup instructions will be added as the scaffold is completed.

## Tech Stack
- **Frontend**: Next.js 15 + TypeScript + Tailwind CSS + shadcn/ui
- **Backend / Auth / DB / Storage**: Supabase
- **AI Image Generation**: Replicate (Flux-based models) or specialized headshot APIs (LightX, BetterPic)
- **Payments**: Stripe
- **Hosting**: Vercel
- **Email**: Resend

## Project Structure
```
proframe-ai/
├── README.md
├── PRD.md                 # Product Requirements Document
├── BUSINESS_PLAN.md       # Business plan & go-to-market
├── landing/               # Static landing page (validate first)
├── app/                   # Next.js application (full MVP)
└── docs/
```

## License
Private – All rights reserved.