# How to Deploy ProFrame AI Landing Page (2 minutes)

## Option 1: Vercel Drag & Drop (Easiest)

1. Go to https://vercel.com/new
2. Sign up / log in with GitHub or email
3. Drag the entire `deploy` folder onto the page
4. Click Deploy
5. Done — you’ll get a free permanent URL

## Option 2: Netlify Drop

1. Go to https://app.netlify.com/drop
2. Drag the `deploy` folder
3. Instant live URL

## Option 3: GitHub + Vercel (Best long-term)

1. Create a new GitHub repo
2. Upload the contents of the `deploy` folder
3. Import the repo in Vercel
4. Deploy

After deploying, you can add a custom domain in the project settings.
